ExecuteAsync(function()
    GameSettingInstance = FindFirstOf("PalGameSetting")
    GameSettingInstance.RarePal_AppearanceProbability = 100.0
end)