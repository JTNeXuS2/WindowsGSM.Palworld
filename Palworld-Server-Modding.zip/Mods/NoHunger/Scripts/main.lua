ExecuteAsync(function()
    GameSettingInstance = FindFirstOf("PalGameSetting")
    GameSettingInstance.StomachDecreace_perSecond_Player = 0.0
end)